import 'react-native-url-polyfill/auto';
import React, { useState, useEffect } from 'react';
import { 
  Text, 
  View, 
  StyleSheet, 
  FlatList, 
  ActivityIndicator, 
  TextInput, 
  TouchableOpacity,
  ScrollView 
} from 'react-native';
import { createClient } from '@supabase/supabase-js';

// 1. ใส่ URL และ Key ของคุณตรงนี้
const supabaseUrl = 'https://peddodbxvztrejkpaprq.supabase.co';
const supabaseAnonKey = 'sb_publishable_oL_eJSsOtDH5oXnOhkpDpw_gFKCumhB';
const supabase = createClient(supabaseUrl, supabaseAnonKey);

export default function App() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItems, setSelectedItems] = useState([]);
  
  // State สำหรับหมวดหมู่ที่ถูกเลือก (ค่าเริ่มต้นคือ 'ทั้งหมด')
  const [selectedCategory, setSelectedCategory] = useState('ทั้งหมด');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const { data: products, error } = await supabase
        .from('products')
        .select('*');

      if (error) {
        console.error('Error fetching:', error);
      } else {
        setData(products);
      }
    } catch (error) {
      console.error('Catch error:', error);
    } finally {
      setLoading(false);
    }
  };

  // ดึงรายชื่อหมวดหมู่แบบไม่ซ้ำกันจากฐานข้อมูล มาทำเป็นแถบเลื่อน
  const categories = ['ทั้งหมด', ...new Set(data.map(item => item.category).filter(Boolean))];

  // ระบบคัดกรองข้อมูล (ทำงานร่วมกันระหว่างช่องค้นหา และ ปุ่มหมวดหมู่)
  const filteredData = data.filter(item => {
    const matchSearch = item.name ? item.name.toLowerCase().includes(searchQuery.toLowerCase()) : false;
    const matchCategory = selectedCategory === 'ทั้งหมด' ? true : item.category === selectedCategory;
    return matchSearch && matchCategory;
  });

  const toggleItem = (item) => {
    const isAlreadySelected = selectedItems.find(i => i.id === item.id);
    if (isAlreadySelected) {
      setSelectedItems(selectedItems.filter(i => i.id !== item.id));
    } else {
      setSelectedItems([...selectedItems, item]);
    }
  };

  const totalPrice = selectedItems.reduce((sum, item) => {
    const itemPrice = Number(item.price) || 0; 
    return sum + itemPrice;
  }, 0);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>คำนวณนะจ้ะ😎😎</Text>

      {/* กล่องแสดงผลรวม (ตะกร้า) */}
      <View style={styles.summaryBox}>
        <Text style={styles.summaryText}>
          ราคารวม: {totalPrice.toLocaleString()} บาท
        </Text>
        <Text style={styles.summarySubText}>
          เลือกไว้ {selectedItems.length} รายการ
        </Text>
      </View>

      {/* ช่องค้นหาสินค้า */}
      <TextInput
        style={styles.searchInput}
        placeholder="🔍 ค้นหาชื่อสินค้า..."
        value={searchQuery}
        onChangeText={setSearchQuery}
      />

      {/* 
        ส่วนของแถบเลื่อนหมวดหมู่แบบแนวนอน 
        ใช้ ScrollView พร้อมตั้งค่า horizontal={true}
      */}
      <View style={styles.categoryWrapper}>
        <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
          {categories.map((cat, index) => (
            <TouchableOpacity
              key={index}
              style={[
                styles.categoryButton,
                selectedCategory === cat && styles.categoryButtonActive
              ]}
              onPress={() => setSelectedCategory(cat)}
            >
              <Text style={[
                styles.categoryText,
                selectedCategory === cat && styles.categoryTextActive
              ]}>
                {cat}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {loading ? (
        <ActivityIndicator size="large" color="#0000ff" />
      ) : (
        <FlatList
          data={filteredData}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => {
            const isSelected = selectedItems.find(i => i.id === item.id);
            return (
              <TouchableOpacity
                style={[styles.item, isSelected && styles.selectedItem]}
                onPress={() => toggleItem(item)}
              >
                <View style={styles.itemInfo}>
                  <Text style={styles.itemName}>{item.name}</Text>
                  <Text style={styles.itemCategory}>หมวดหมู่: {item.category}</Text>
                  <Text style={styles.itemPrice}>
                    {/* ใช้ toLocaleString() เพื่อใส่ลูกน้ำคั่นหลักพันให้ดูสวยงาม */}
                    ราคา: {item.price ? `${Number(item.price).toLocaleString()} บาท` : 'ไม่ได้ระบุราคา'}
                  </Text>
                </View>
                <Text style={styles.checkIcon}>
                  {isSelected ? '✅' : '➕'}
                </Text>
              </TouchableOpacity>
            );
          }}
          ListEmptyComponent={<Text style={styles.emptyText}>ไม่พบสินค้าที่ค้นหา</Text>}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 50,
    paddingHorizontal: 15,
    backgroundColor: '#f8f9fa',
  },
  header: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
    color: '#333',
  },
  summaryBox: {
    backgroundColor: '#e3f2fd',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#90caf9',
  },
  summaryText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1565c0',
  },
  summarySubText: {
    fontSize: 14,
    color: '#555',
    marginTop: 5,
  },
  searchInput: {
    backgroundColor: 'white',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    marginBottom: 10,
    fontSize: 16,
  },
  categoryWrapper: {
    marginBottom: 15,
  },
  categoryButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#e0e0e0',
    borderRadius: 20,
    marginRight: 10,
  },
  categoryButtonActive: {
    backgroundColor: '#1565c0',
  },
  categoryText: {
    color: '#333',
    fontWeight: 'bold',
  },
  categoryTextActive: {
    color: '#fff',
  },
  item: {
    flexDirection: 'row',
    padding: 15,
    backgroundColor: 'white',
    marginBottom: 10,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  selectedItem: {
    backgroundColor: '#f0fdf4',
    borderColor: '#4ade80',
  },
  itemInfo: {
    flex: 1,
  },
  itemName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  itemCategory: {
    fontSize: 12,
    color: '#888',
    marginTop: 2,
  },
  itemPrice: {
    fontSize: 14,
    color: '#d32f2f',
    fontWeight: 'bold',
    marginTop: 4,
  },
  checkIcon: {
    fontSize: 20,
    marginLeft: 10,
  },
  emptyText: {
    textAlign: 'center',
    marginTop: 20,
    color: '#888',
    fontSize: 16,
  }
});